package com.nico.assistant

import android.content.Context

/** مكونات مشتركة بين التطبيق وخدمة الاستماع (نفس العملية = موديل واحد في الرام). */
object Shared {
    lateinit var app: Context
    fun init(c: Context) { if (!::app.isInitialized) app = c.applicationContext }
    val store by lazy { Store(app) }
    val people by lazy { People(app) }
    val llm by lazy { LlmEngine(app) }
    val agent by lazy { Agent(llm) }
    val vosk by lazy { VoskSpeech(app) }
}
