package com.nico.assistant

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock

/** مهارات محلية: ذاكرة طويلة المدى، تذكير بنص، تقسيم الأوامر المتعددة، وتمييز الأوامر عن الأسئلة. */
object Skills {
    fun norm(s: String): String {
        var t = s.lowercase().trim()
        t = t.replace(Regex("[\u064B-\u0652\u0640]"), "")
        t = t.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه').replace('ى', 'ي')
        val ar = "٠١٢٣٤٥٦٧٨٩"; ar.forEachIndexed { i, c -> t = t.replace(c, ('0' + i)) }
        return t.replace(Regex("\\s+"), " ")
    }

    fun handle(raw: String, store: Store, ctx: Context): String? {
        val q = norm(raw)
        // --- الذاكرة (الحفظ بيحصل بس لما المستخدم يطلب صراحة) ---
        Regex("^(?:افتكر|فتكر|تفتكر|خلي بالك)\\s*(?:ان|انه|انى)?\\s+(.+)$").find(q)?.let {
            val m = it.groupValues[1].trim(); store.addMemory(m); return "تمام، هفتكر إن $m."
        }
        if (Regex("^انسي\\s+(?:كل حاجه|الكل|كل حاجة|الذاكره)").containsMatchIn(q)) { store.clearMemory(); return "مسحت كل اللي كنت فاكره عنك." }
        Regex("^انسي\\s+(.+)$").find(q)?.let {
            val n = store.removeMemoryLike(it.groupValues[1].trim())
            return if (n > 0) "نسيت." else "مكنتش فاكر حاجة بالشكل ده."
        }
        if (Regex("(?:ايه|اي) اللي (?:تعرفه|فاكره|فاكر) عني|فاكر ايه عني|تعرف ايه عني").containsMatchIn(q))
            return if (store.memories.isEmpty()) "لسه مفيش حاجة محفوظة. قولي: افتكر إن ... وهحفظها."
            else "فاكر إن: " + store.memories.joinToString("، ")
        // --- تذكير بنص ---
        Regex("(?:فكرني|ذكرني)\\s+بعد\\s*(\\d+)?\\s*(ثانيه|ثواني|دقيقه|دقايق|ساعه|ساعات)\\s*(?:ان|اني|انك|اعمل|ب)?\\s*(.*)").find(q)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: 1
            val sec = n * when (it.groupValues[2]) { "ثانيه", "ثواني" -> 1; "دقيقه", "دقايق" -> 60; else -> 3600 }
            val msg = it.groupValues[3].ifBlank { "تذكير من نيكو" }
            return try {
                ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, msg).putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "تمام، هفكرك بعد ${it.groupValues[1].ifBlank { "1" }} ${it.groupValues[2]}: $msg"
            } catch (e: Exception) { "معرفتش أظبط التذكير على الجهاز ده." }
        }
        return null
    }

    private val conn = Regex("\\s+(?:و?بعدين|و?بعدها|بعد كده|و?بعد كده|ثم|وبعد ذلك)\\s+")
    fun split(t: String): List<String> = t.split(conn).map { it.trim() }.filter { it.isNotEmpty() }

    private val verbs = setOf("افتح", "ادخل", "دور", "ابحث", "ابعت", "ارسل", "اكتب", "اضغط", "شغل", "نزل", "سجل", "صور", "روح", "اعمل", "خلي", "وريني", "ورني",
        "ضيف", "امسح", "غير", "عدل", "حمل", "ثبت", "شارك", "ارفع", "اختار", "حدد", "اتصل", "كلم", "نفذ", "جرب", "اتصرف", "رد", "ابدا", "كمل", "انسخ", "الصق")
    fun isCommand(t: String): Boolean {
        val q = norm(t); val first = q.substringBefore(' ')
        return first in verbs
    }
}
