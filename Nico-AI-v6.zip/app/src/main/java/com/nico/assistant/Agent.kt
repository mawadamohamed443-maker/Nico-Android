package com.nico.assistant

import org.json.JSONObject

/** وكيل بيشوف الشاشة (Accessibility) وبيقرر خطوة خطوة بالذكاء المحلي لحد ما يخلص الهدف. */
class Agent(private val llm: LlmEngine) {
    private val sensitive = listOf("ارسال", "إرسال", "ابعت", "send", "حذف", "مسح", "delete", "remove", "دفع", "pay", "شراء", "buy",
        "تحويل", "transfer", "اتصال", "call", "تأكيد الطلب", "confirm", "order", "place order")

    private val sys = "أنت وكيل بيتحكم في موبايل أندرويد لتنفيذ هدف المستخدم خطوة خطوة. رد دايماً بـ JSON واحد بس من غير أي شرح."

    private fun parse(s: String): JSONObject? = try {
        Regex("\\{[^{}]*\\}").find(s)?.let { JSONObject(it.value) }
    } catch (_: Exception) { null }

    fun run(goal: String, allowSensitive: Boolean, screen: () -> String, pkg: () -> String,
            exec: (String, String) -> String, log: (String) -> Unit): String {
        val done = ArrayList<String>()
        for (step in 1..8) {
            val p = "الهدف: $goal\nالتطبيق الحالي: ${pkg().ifBlank { "غير معروف" }}\nمحتوى الشاشة:\n${screen().take(1200)}\n" +
                "الخطوات اللي اتعملت: ${if (done.isEmpty()) "ولا خطوة" else done.takeLast(4).joinToString(" | ")}\n\n" +
                "اختار الخطوة الجاية بس. الأشكال المسموحة:\n" +
                "{\"a\":\"open\",\"v\":\"اسم التطبيق\"}\n{\"a\":\"click\",\"v\":\"نص الزرار زي ما هو على الشاشة\"}\n" +
                "{\"a\":\"type\",\"v\":\"النص\"}\n{\"a\":\"scroll\",\"v\":\"down\"} أو up\n{\"a\":\"back\"}\n{\"a\":\"home\"}\n" +
                "{\"a\":\"done\",\"v\":\"رسالة قصيرة للمستخدم بالنتيجة\"} لما الهدف يتنفذ أو يتعذر."
            val j = parse(llm.generate(sys, p, useHist = false))
                ?: return "الذكاء ماردش بشكل أقدر أنفذه في الخطوة $step. جربي تصيغي الأمر أبسط."
            val a = j.optString("a"); val v = j.optString("v")
            if (a == "done") return v.ifBlank { "خلصت." }
            if (a == "click" && !allowSensitive && sensitive.any { v.lowercase().contains(it) })
                return "وقفت قبل خطوة حساسة (\"$v\"). نفّذيها بنفسك أو اسمحي بيها من الإعدادات."
            val r = exec(a, v); log("[$step] $r"); done.add("$a:$v ← $r")
            Thread.sleep(1600)
        }
        return "وقفت بعد 8 خطوات. قوليلي أكمل لو لسه محتاج."
    }
}
