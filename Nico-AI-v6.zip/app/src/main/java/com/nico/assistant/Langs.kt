package com.nico.assistant

/** لغة مدعومة: كود، اسم العرض، اسم إنجليزي (للذكاء)، locale للنطق، موديل Vosk وحجمه. */
data class Lang(val code: String, val label: String, val english: String, val tag: String, val model: String, val mb: Int)

object Langs {
    val all = listOf(
        Lang("ar", "العربية (دايماً)", "Arabic", "ar-EG", "vosk-model-ar-mgb2-0.4", 318),
        Lang("en", "English", "English", "en-US", "vosk-model-small-en-us-0.15", 40),
        Lang("fr", "Français", "French", "fr-FR", "vosk-model-small-fr-0.22", 41),
        Lang("de", "Deutsch", "German", "de-DE", "vosk-model-small-de-0.15", 45),
        Lang("es", "Español", "Spanish", "es-ES", "vosk-model-small-es-0.42", 39),
        Lang("ru", "Русский", "Russian", "ru-RU", "vosk-model-small-ru-0.22", 45),
        Lang("tr", "Türkçe", "Turkish", "tr-TR", "vosk-model-small-tr-0.3", 35),
        Lang("it", "Italiano", "Italian", "it-IT", "vosk-model-small-it-0.22", 48),
        Lang("pt", "Português", "Portuguese", "pt-BR", "vosk-model-small-pt-0.3", 31),
        Lang("fa", "فارسی", "Persian", "fa-IR", "vosk-model-small-fa-0.5", 60)
    )
    fun byCode(c: String) = all.firstOrNull { it.code == c } ?: all[0]
    const val SPK_MODEL = "vosk-model-spk-0.4"
    const val SPK_MB = 13
    fun spkUrl() = "https://alphacephei.com/vosk/models/$SPK_MODEL.zip"
    fun url(l: Lang) = "https://alphacephei.com/vosk/models/${l.model}.zip"
}
