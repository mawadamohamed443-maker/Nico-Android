package com.nico.assistant

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * نيكو: كرة مائية لونها ميد نايت. حدودها بتتعوّج مع الكلام (وبتتأثر بالمشاعر: الغضب بيخليها مسننة وسريعة،
 * الزعل بيخليها بطيئة وهادية). من غير وش - المشاعر بتظهر في كلام نيكو نفسه.
 */
class WaterOrbView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state = State.IDLE
    var lowPower = false
    private var emo = Emotion.NEUTRAL
    private var emoUntil = 0L
    fun feel(e: Emotion, ms: Long = 5000) { emo = e; emoUntil = if (e == Emotion.NEUTRAL) 0L else nowMs() + ms }
    fun pulse(v: Float = 1f) { target = v.coerceIn(0f, 1f) }
    private fun nowMs() = System.nanoTime() / 1_000_000

    private var target = 0f
    private var level = 0f
    private var amp = 0.006f
    private var env = 0f
    private val t0 = System.nanoTime()

    private var cx = 0f; private var cy = 0f; private var r = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blob = Path(); private val wave = Path()
    private var bg: Shader? = null; private var shine: Shader? = null
    private var w1: Shader? = null; private var w2: Shader? = null

    private val GLOW = 0xFF3347D6.toInt()   // وهج أزرق ميد نايت
    private val RIM = 0xFF6B7CFF.toInt()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f; r = min(w, h) / 2f * 0.70f
        bg = RadialGradient(cx, cy, r * 1.1f, intArrayOf(0xFF0B0B3B.toInt(), 0xFF03030F.toInt()), null, Shader.TileMode.CLAMP)
        w1 = LinearGradient(0f, cy - r, 0f, cy + r, intArrayOf(0xDD3A46C8.toInt(), 0xEE191970.toInt(), 0xFF0A0A3A.toInt()), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        w2 = LinearGradient(0f, cy - r, 0f, cy + r, intArrayOf(0x887C8BFF.toInt(), 0x883A46C8.toInt(), 0x88191970.toInt()), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        shine = RadialGradient(cx - r * .35f, cy - r * .45f, r * .75f, intArrayOf(0x44FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
    }

    /** حدود الكرة: دايرة + موجات بتتغير مع الوقت والكلام. */
    private fun buildBlob(t: Float, a: Float, e: Emotion) {
        blob.reset()
        val n = 96
        val k1: Int; val k2: Int; val k3: Int; val sp: Float
        when (e) {
            Emotion.ANGRY -> { k1 = 5; k2 = 8; k3 = 13; sp = 1.9f }
            Emotion.SAD -> { k1 = 2; k2 = 3; k3 = 4; sp = 0.55f }
            Emotion.LAUGH, Emotion.HAPPY -> { k1 = 3; k2 = 5; k3 = 7; sp = 1.3f }
            else -> { k1 = 2; k2 = 3; k3 = 5; sp = 1f }
        }
        for (i in 0..n) {
            val th = i.toFloat() / n * 6.2831855f
            val d = a * (sin(k1 * th + t * 3.1f * sp) * 0.5f + sin(k2 * th - t * 4.3f * sp + 1.3f) * 0.3f + sin(k3 * th + t * 5.7f * sp + 2.1f) * 0.2f)
            val rr = r * (1f + d)
            val x = cx + rr * cos(th); val y = cy + rr * sin(th)
            if (i == 0) blob.moveTo(x, y) else blob.lineTo(x, y)
        }
        blob.close()
    }

    private fun drawWave(cv: Canvas, level: Float, a: Float, k: Float, phase: Float, sh: Shader?) {
        wave.reset(); val left = cx - r * 1.2f; val right = cx + r * 1.2f
        wave.moveTo(left, cy + r * 1.2f)
        var x = left
        while (x <= right + 6f) { wave.lineTo(x, level + a * sin(x * k + phase)); x += 6f }
        wave.lineTo(right, cy + r * 1.2f); wave.close()
        p.reset(); p.isAntiAlias = true; p.shader = sh; cv.drawPath(wave, p)
    }

    override fun onDraw(cv: Canvas) {
        if (r <= 0f) return
        val t = (System.nanoTime() - t0) / 1e9f
        if (emoUntil != 0L && nowMs() > emoUntil) { emo = Emotion.NEUTRAL; emoUntil = 0L }
        val e = emo

        target *= 0.93f; level += (target - level) * 0.18f
        // غلاف الصوت أثناء الكلام: مقاطع متقطعة زي النطق الحقيقي
        val speech = abs(sin(t * 7.3f)) * (0.55f + 0.45f * abs(sin(t * 3.1f + 1f))) * (0.7f + 0.3f * sin(t * 13f))
        env += (speech.coerceIn(0f, 1f) - env) * 0.25f

        val tgtAmp = when (state) {
            State.IDLE -> 0.008f
            State.LISTENING -> 0.012f + 0.06f * level
            State.THINKING -> 0.02f + 0.01f * sin(t * 3f)
            State.SPEAKING -> 0.03f + 0.085f * env
        }
        amp += (tgtAmp - amp) * 0.22f
        val speed = if (state == State.THINKING) 4.5f else if (state == State.IDLE) 1.2f else 2.6f
        val scale = 1f + when (state) {
            State.IDLE -> 0.012f * sin(t * 1.5f)
            State.LISTENING -> 0.02f + 0.05f * level
            State.THINKING -> 0.015f * sin(t * 3f)
            State.SPEAKING -> 0.02f * env
        }

        buildBlob(t, amp, e)
        cv.save(); cv.scale(scale, scale, cx, cy)

        // هالة زرقاء حوالين الحدود المتعوجة
        for (i in 6 downTo 1) {
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE
            p.strokeWidth = r * 0.04f * i; p.color = GLOW
            var al = 10 + 3 * (7 - i)
            if (state == State.SPEAKING) al += (30 * env).toInt()
            if (state == State.LISTENING) al += (30 * level).toInt()
            p.alpha = al.coerceAtMost(90); cv.drawPath(blob, p)
        }

        cv.save(); cv.clipPath(blob)
        p.reset(); p.isAntiAlias = true; p.shader = bg; cv.drawCircle(cx, cy, r * 1.3f, p)
        val lvl = cy - r * (0.10f + 0.10f * level); val a = r * (0.03f + amp * 1.4f)
        drawWave(cv, lvl + r * .05f, a * 1.2f, 0.021f, -t * speed * 0.8f + 1.7f, w2)
        drawWave(cv, lvl, a, 0.017f, t * speed, w1)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x886B7CFF.toInt()
        for (i in 0 until 5) {
            val bt = (t * (0.15f + i * 0.04f) + i * 0.37f) % 1f
            val bx = cx + r * 0.55f * sin(i * 2.3f + t * 0.4f); val by = cy + r - bt * r * 1.5f
            if (by > lvl) cv.drawCircle(bx, by, r * (0.02f + 0.012f * i), p)
        }
        cv.restore()

        p.reset(); p.isAntiAlias = true; p.shader = shine; cv.drawPath(blob, p)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.025f; p.color = RIM; p.alpha = 0xCC
        cv.drawPath(blob, p)
        if (state == State.THINKING) {
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.045f; p.strokeCap = Paint.Cap.ROUND; p.color = Color.WHITE
            cv.drawArc(cx - r * 1.12f, cy - r * 1.12f, cx + r * 1.12f, cy + r * 1.12f, t * 220f, 70f, false, p)
        }
        cv.restore()
        if (lowPower && state == State.IDLE && e == Emotion.NEUTRAL) postInvalidateDelayed(110) else postInvalidateOnAnimation()
    }
}
