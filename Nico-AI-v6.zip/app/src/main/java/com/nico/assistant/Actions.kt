package com.nico.assistant

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** تنفيذ خطوات الوكيل على الـ main thread من أي thread. */
object Actions {
    private val main = Handler(Looper.getMainLooper())
    fun <T> onMain(f: () -> T): T? {
        if (Looper.myLooper() == Looper.getMainLooper()) return f()
        var r: T? = null; val l = CountDownLatch(1)
        main.post { try { r = f() } catch (_: Throwable) {}; l.countDown() }
        l.await(6, TimeUnit.SECONDS); return r
    }

    fun exec(brain: NicoBrain, a: String, v: String): String = onMain {
        val acc = NicoAccessibilityService.inst
        when (a) {
            "open" -> brain.handle("افتح $v")?.ifBlank { null } ?: "فتحت $v"
            "click" -> if (acc?.clickText(v) == true) "ضغطت على \"$v\"" else "ملقيتش \"$v\" على الشاشة"
            "type" -> if (acc?.typeText(v) == true) "كتبت \"$v\"" else "ملقيتش خانة كتابة"
            "scroll" -> if (acc?.scroll(v != "up") == true) "سكرولت" else "معرفتش أسكرول"
            "back" -> { acc?.global(AccessibilityService.GLOBAL_ACTION_BACK); "رجعت" }
            "home" -> { acc?.global(AccessibilityService.GLOBAL_ACTION_HOME); "روحت للرئيسية" }
            else -> "أمر غير معروف: $a"
        }
    } ?: "التنفيذ اتأخر"
}
