package com.nico.assistant

import android.content.Context
import org.json.JSONArray
import java.io.File

/** تخزين دائم: سجل المحادثة + الذاكرة طويلة المدى (بموافقة المستخدم: بتتحفظ بس لما يقول "افتكر"). */
class Store(ctx: Context) {
    private val hf = File(ctx.filesDir, "history.json")
    private val mf = File(ctx.filesDir, "memory.json")
    private fun read(f: File): MutableList<String> = try {
        val a = JSONArray(f.readText()); MutableList(a.length()) { a.getString(it) }
    } catch (_: Exception) { mutableListOf() }
    private fun write(f: File, l: List<String>) { try { f.writeText(JSONArray(l).toString()) } catch (_: Exception) {} }

    val lines = read(hf)
    val memories = read(mf)

    fun addLine(s: String) { lines.add(s); while (lines.size > 400) lines.removeAt(0); write(hf, lines) }
    fun clearHistory() { lines.clear(); write(hf, lines) }
    fun addMemory(s: String) { if (s.isNotBlank() && memories.none { it == s }) { memories.add(s.trim()); write(mf, memories) } }
    fun removeMemory(i: Int) { if (i in memories.indices) { memories.removeAt(i); write(mf, memories) } }
    fun removeMemoryLike(t: String): Int { val n = memories.size; memories.removeAll { it.contains(t) }; write(mf, memories); return n - memories.size }
    fun clearMemory() { memories.clear(); write(mf, memories) }
    fun memoryText() = memories.joinToString("؛ ")

    /** آخر أزواج (سؤال، رد) من السجل عشان الذكاء يكمل من حيث وقف. */
    fun pairs(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var q: String? = null
        for (l in lines) {
            if (l.startsWith("أنتِ: ")) q = l.removePrefix("أنتِ: ")
            else if (l.startsWith("نيكو: ") && q != null) { out.add(q to l.removePrefix("نيكو: ")); q = null }
        }
        return out
    }
}
